#!/usr/bin/env python

import os
import re
import subprocess
import sys
import matplotlib.pyplot as plt
from time import sleep

def cmd(command):
    '''Runs the given shell command and returns its standard output as a string.
    Throws an exception if the command returns anything other than 0.'''
    return subprocess.check_output(command, universal_newlines=True)


if __name__ == "__main__":

    # Build the program.
    cmd(['make'])

    # Run the program and create the plot.
    graph_value_write = [];
    graph_value_read = [];

    for pgsize in range(2,33):
        output = cmd(['./write_fixed_len_pages', 'tuples', 'results', str(pgsize*1000)])
        time = output.splitlines()
        record_num = time[-3].split()
        millisec = time[-1].split()
        graph_value_write.append(float(record_num[-1])/(float(millisec[-1])/1000))
        sleep(5.5)

        output = cmd(['./read_fixed_len_page', 'results', str(pgsize*1000)])
        time = output.splitlines()
        record_num = time[-3].split()
        millisec = time[-1].split()
        graph_value_read.append(float(record_num[-1])/(float(millisec[-1])/1000))
        sleep(5.5)
    
    #+print graph_value 
   
    x =range(2000,33000,1000)

    plt.plot(x, graph_value_write, 'bd-')
    plt.xlabel('Page size')
    plt.ylabel('Performance(Records/s)')
    plt.title('Page Write Speed')
    plt.savefig("experiment 3 write graph")
    plt.show()
    plt.close()

    plt.plot(x, graph_value_read, 'rd-')
    plt.xlabel('Page size')
    plt.ylabel('Performance(Records/s)''Delay(ms)')
    plt.title('Page Read Speed')
    plt.savefig("experiment 3 read graph")
    plt.show()
    plt.close()
